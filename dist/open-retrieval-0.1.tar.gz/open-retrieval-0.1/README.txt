# `Open Retrieval`

Retrieve semantically close text embeddings using a prebuilt FAISS index and retrieval model from HF transformers